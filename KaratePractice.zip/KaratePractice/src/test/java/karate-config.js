function fn() {
	var env = karate.env; //get system property 'karate.env' karate.log
	if (!env) {
		env = 'dev';
	}
	
	var config = {
		env: env,
		myVarName: 'hello karate',
		baseUrl: 'https://gorest.co.in',
		tokenID: 'acb109e8e9614298d1dab03bd355cbc9038c6630b91fc0e99d78b0705721e66f'
	}

	if (env == 'dev') {
		//customize
		//e.g. config.foo = 'bar';
	} else if (env == 'e2e') {
		//customize
	}
	return config;
}